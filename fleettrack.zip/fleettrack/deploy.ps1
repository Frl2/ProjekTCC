$PROJECT_ID = "e-42-498310"
$REGION = "asia-southeast2"
$REPO = "fleettrack-repo"
$DB_PASSWORD = "admin123"
$CLOUD_SQL_CONN = "e-42-498310:asia-southeast2:fleettrack-mysql"

$AUTH_IMAGE = "asia-southeast2-docker.pkg.dev/$PROJECT_ID/$REPO/auth-service:latest"
$LOG_IMAGE = "asia-southeast2-docker.pkg.dev/$PROJECT_ID/$REPO/logistics-service:latest"

# Cloud Run otomatis mengatur PORT, jadi kita hapus PORT dari sini
$AUTH_ENV = "DB_HOST=/cloudsql/$CLOUD_SQL_CONN,DB_USER=root,DB_PASSWORD=$DB_PASSWORD,DB_NAME=auth_db,JWT_SECRET=fleettrack_jwt_secret_key_2024,JWT_EXPIRES_IN=24h"
$LOG_ENV = "DB_HOST=/cloudsql/$CLOUD_SQL_CONN,DB_USER=root,DB_PASSWORD=$DB_PASSWORD,DB_NAME=logistics_db,JWT_SECRET=fleettrack_jwt_secret_key_2024"

Write-Host "--- Mendeploy Auth Service ---" -ForegroundColor Cyan
gcloud run deploy fleettrack-auth-service --image $AUTH_IMAGE --region $REGION --platform managed --allow-unauthenticated --add-cloudsql-instances $CLOUD_SQL_CONN --set-env-vars $AUTH_ENV

Write-Host "--- Mendeploy Logistics Service ---" -ForegroundColor Cyan
gcloud run deploy fleettrack-logistics-service --image $LOG_IMAGE --region $REGION --platform managed --allow-unauthenticated --add-cloudsql-instances $CLOUD_SQL_CONN --set-env-vars $LOG_ENV

Write-Host "--- SELESAI ---" -ForegroundColor Green
